# pyleargist-python3
Pyleargist Python 3 Version. Tested with anaconda environment and Tensorflow 2.0 docker image on Ubuntu 20

## Pre-requisites
`pip install numpy Pillow Cython`

`sudo apt-get install fftw3-dev`
## Setup
CD into the repo: 
`cd pyleargist-python3`

Build and install library: 

`python setup.py build`

`python setup.py install`
