# 
#   MLCV Winter 2015
#   Homework Assignment 03 - Hidden Markov Models
#
#   Exercise 1d) Viterbi algorithm
#
###########################################################################

import numpy as np


def viterbi(observations, P_start, P_trans, P_sense, state_space, observation_space):
    """
    Viterbi algorithm to recursively estimate the most likely taken path based on observations and sensor model
    :param observations: T-dimensional vector, a sequence of observations {z_t}
    :param P_start: K-dimensional vector, the initial probability of each state p(x_{t=0})
    :param P_trans: KxK matrix, the state transition matrix p(x_t|x_{t-1})
    :param P_sense: QxK matrix, the observation model p(z_i|x_i)
    :param state_space: the intuitive state space
    :param observation_space: the intuitive observation space
    :return: most likely path, likelihood
    """

    Q, K = P_sense.shape  # observations_space_size, state_space_size
    # Initialize
    print('\nObservation #%d: %s' % (0, observation_space[observations[0]]))
    states_posteriors = [P_sense[observations[0], state] * P_start[state] for state in range(K)]
    print('Posterior probabilities after first observation')
    [print('State %d: %s: p= %f' % (i, state_space[state], post)) for i, (state, post)
                                    in enumerate(zip(range(K), states_posteriors))]

    ml_state = np.argmax(states_posteriors)
    ml_state_prob = states_posteriors[ml_state]
    print('Most likely (p=%f) state : %s' % (ml_state_prob, state_space[ml_state]))

    paths = {state:[state] for state in range(K)}

    # Find (recursively) the most probable path
    for t in range(1, len(observations)):
        observation = observations[t]
        states_priors = states_posteriors.copy()
        print('\nObservation #%d: %s' % (t, observation_space[observation]))

        # that can lead to each state
        for cur_state in range(K):
            probs_prev_state = [states_priors[prev_state] * P_trans[prev_state, cur_state] for prev_state in range(K)]
            # max_prob_prev_state = max(probs_prev_state)
            # ml_prev_states = [k for k, s in enumerate(probs_prev_state) if s == max_prob_prev_state]

            ml_prev_state = np.argmax(probs_prev_state)
            max_prob_prev_state = probs_prev_state[ml_prev_state]
            print('State %d: Most likely (p=%f) previous states : %s' %
                                (cur_state, max_prob_prev_state, ml_prev_state))

            states_posteriors[cur_state] = P_sense[observation, cur_state] * max_prob_prev_state

            # for ml_prev_state in ml_prev_states:
            paths[cur_state] = paths[ml_prev_state] + [cur_state]
            # paths[cur_state].append(paths[ml_prev_state] + [cur_state])

    # Return the most likely sequence and its probability
    ml_prev_state = np.argmax(states_posteriors)
    max_prob_prev_state = states_posteriors[ml_prev_state]
    paths = paths[ml_prev_state]

    return paths, max_prob_prev_state


def main():
    # Initializations
    world = np.array([['G', 'R', 'B'],
                      ['R', 'B', 'G'],
                      ['B', 'G', 'R']])

    observation_space = ['R', 'G', 'B']
    state_space = [np.array([i, j]) for i in range(world.shape[0]) for j in range(world.shape[1])]

    def get_state_idx(state, world):
        return state[0] * world.shape[1] + state[1]

    def is_valid_state(state, world):
        for dim in range(len(state)):
            if state[dim] < 0 or state[dim] >= world.shape[dim]:
                return False
        return True

    # Define state transition matrix
    P_trans = np.zeros(shape=(len(state_space), len(state_space)))
    moves = [(0,1), (0,-1), (-1,0), (1,0)] # up, down, left, right
    moves = [np.array(move) for move in moves]
    p_move = 1 / len(moves)

    for state_from, state in enumerate(state_space):
        # Try to move up, down, left, right
        for move in moves:
            new_state = state + move
            if not is_valid_state(new_state, world): # out of bounds
                new_state = state

            state_to = get_state_idx(new_state, world)
            P_trans[state_from, state_to] += p_move

    # Define observation model p(z|x) from first exercise 1
    # Each column is the probability to sense colors z, given one color x
    P_zx = np.array([[0.8, 0.1, 0.1],
                     [0.1, 0.6, 0.2],
                     [0.1, 0.3, 0.7]])

    P_sense = np.zeros(shape=(len(observation_space), len(state_space)))
    for state_id, state in enumerate(state_space):
        state_color = world[state[0], state[1]]
        observation_id = observation_space.index(state_color)
        P_sense[:, state_id] = P_zx[:, observation_id]

    # Define initial probabilities p(x0)
    P_init = np.ones(len(state_space)) / len(state_space)

    # Observed sequence
    observations = ['R', 'G', 'G']
    observed_sequence = np.array([observation_space.index(observation) for observation in observations])

    path_vit, prob_vit = viterbi(observed_sequence, P_init, P_trans, P_sense, state_space, observation_space)
    print('\nThe most likely taken path with probability %.4f is %s or in coordinates:' % (prob_vit, path_vit))
    print([list(state_space[state_id]) for state_id in path_vit])

if __name__ == '__main__':
    main()