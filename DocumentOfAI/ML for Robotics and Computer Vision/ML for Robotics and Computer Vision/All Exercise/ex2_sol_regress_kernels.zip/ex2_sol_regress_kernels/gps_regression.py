## GPs regression
import numpy as np
from numpy.linalg import inv, cholesky
import matplotlib.pyplot as plt

# X_train = np.array([-0.8372, -0.4558,  0.6902,  0.1114, -0.4678])
# Y_train = np.array([-0.6414, -1.0286, -0.6893, -1.4021, -1.0594])
# X_star = np.array([-0.5, 0.5])

sigma_noise = 0.5
x_min, x_max = -5, 5
X_train = np.arange(x_min, x_max, step=1.6)
# Simulate sinusoid with some gaussian noise
Y_train = [10*np.sin(x) + (np.random.rand() - 0.5)*sigma_noise for x in X_train]

# Test data
X_star = np.arange(x_min, x_max, step=0.1)

train_data = np.vstack((X_train, Y_train)).T
print(train_data.shape)
np.savetxt('train_data.txt', train_data, fmt='%2.4f')


## Kernel function
def rbf_kernel(x, y, l=1.0, sigma_f=1.0, sigma_n=0.5):
    return sigma_f**2 * np.exp(-(x - y)**2 / (2*l**2)) + sigma_n**2*(x==y)


n_train, n_test = len(X_train), len(X_star)
l=3
## Compute the Gram matrix K
K = np.array([rbf_kernel(x, y, l=l) for x in X_train for y in X_train]).reshape((n_train, n_train))

## a) Compute Ytest (\bar(y_*))
L = cholesky(K)

K_star = np.array([rbf_kernel(x, y) for x in X_train for y in X_star]).reshape((n_train, n_test))

alpha = inv(L.T).dot(inv(L).dot(Y_train)) #L.T \ ( L \ Y_train )

yMean = K_star.T.dot(alpha)

## b) Try different values for the hyperparameter l. 
#	 Plot $\mathbf{y_*}$ against $\mathbf{x_*}$ with the confidence intervals (two standard deviations). 
#    How does the function change?


l_values = np.linspace(0.1, 3, num=8)
nPlotCols = 3
nPlotRows = np.ceil(len(l_values)/ nPlotCols)
fig = plt.figure()
plt.title('GP regression, varying length scale')
plt.subplot(nPlotRows, nPlotCols, 1)
plt.axis('normal')
plt.scatter(X_star, yMean, color='r', marker='*', label='mean predictions')
plt.scatter(X_train, Y_train, color='g', marker='o', label='training data')
plt.title('Mean predictions for l=%f' % l, fontweight='bold')

for i, l in enumerate(l_values):

    K = np.array([rbf_kernel(x, y, l) for x in X_train for y in X_train]).reshape((n_train, n_train))

    K_star = np.array([rbf_kernel(x, y, l) for x in X_train for y in X_star]).reshape((n_train, n_test))

    K_starstar = np.array([rbf_kernel(x, y, l) for x in X_star for y in X_star]).reshape((n_test, n_test))
    
    L = cholesky(K)

    alpha = inv(L.T).dot(inv(L).dot(Y_train))  # L.T \ ( L \ Y_train )

    Y_star = K_star.T.dot(alpha)

    v = inv(L).dot(K_star)

    V_star = K_starstar - v.T.dot(v) # = Kstarstar - K_star'*inv(K)*K_star

    std_star = np.diag(V_star)
    
    plt.subplot(nPlotRows, nPlotCols, i+2)
    plt.axis('normal')
    plt.title('l=%.4f' % l, fontweight='bold')
    # Plot predictions
    plt.plot(X_star, Y_star, '-r', label='mean')
    plt.plot(X_star, Y_star+3*std_star, '-b', label='+3std')
    plt.plot(X_star, Y_star-3*std_star, '-b', label='-3std')
    plt.fill_between(X_star, Y_star - 3*std_star, Y_star + 3*std_star, facecolor='gray', interpolate=True)
    plt.scatter(X_train, Y_train, color='g', marker='o', label='training data')

plt.legend()
plt.show()
     






