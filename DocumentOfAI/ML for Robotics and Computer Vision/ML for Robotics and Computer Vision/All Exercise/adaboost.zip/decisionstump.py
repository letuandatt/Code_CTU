import numpy as np
from operator import lt, ge


class DecisionStump:
    """
    A simple decision stump classifier (axis-aligned hyperplane)
    """
    def __init__(self, dim=0, value=0, op=lt):
        """
        :param dim: the best dimension (feature) to split for
        :param value: the decision value on which to split
        :param op: the operator to use when comparing to the value (less than or greater than)
        """
        self.dim = dim
        self.value = value
        self.op = op

    def update(self, dim=None, value=None, op=None):
        if dim is not None: self.dim = dim
        if value is not None: self.value = value
        if op is not None: self.op = op

    def predict(self, X):
        return np.array([1 if self.op(x, self.value) else -1 for x in X[:, self.dim]])

    def fit(self, X, Y, sample_weights, num_splits=100):
        """
        Fit a decision stump classifier
        :param X: nxd matrix, n observations with d properties each
        :param Y: n-dimensional vector, the true binary labels of the observations \in {-1,+1}
        :param sample_weights: n-dimensional vector, the weights of the observations
        :param num_splits: number of split values to evaluate
        :return:
        """
        n, d = X.shape
        min_error = np.inf
        # This for loop could be parallelized
        for dim in range(d):
            min_dim_err, split_value, op =self._fit_dim(X[:, dim], Y, sample_weights, num_splits)
            if min_dim_err < min_error:
                min_error = min_dim_err
                self.update(dim, split_value, op)

    def _fit_dim(self, X, Y, sample_weights, num_splits):
        """
        Fit a one-dimensional decision stump classifier
        :param X: nxd matrix, n observations with d properties each
        :param Y: n-dimensional vector, the true binary labels of the observations \in {-1,+1}
        :param sample_weights: n-dimensional vector, the weights of the observations
        :param num_splits: number of split values to evaluate
        :return:
        """
        min_error, best_value, op = np.inf, None, lt
        num_splits = min(num_splits, len(Y)-1)
        # Find an axis-aligned hyperplane that minimizes the classification error
        for value in np.linspace(min(X), max(X), num_splits, endpoint=False):
            predictions = [1 if x < value else -1 for x in X]
            idx_err = np.not_equal(predictions, Y)
            Jm = np.dot(sample_weights, idx_err)
            if Jm < min_error:
                min_error, best_value, op = Jm, value, lt

            # Also consider the error for inverted predictions
            Jm = np.dot(sample_weights, ~idx_err)
            if Jm < min_error:
                min_error, best_value, op = Jm, value, ge

        return min_error, best_value, op
