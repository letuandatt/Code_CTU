import matplotlib.pyplot as plt
import numpy as np
from mkmeans import mkmeans
from scipy import misc



def compression_with_kmeans():
    '''
    Each channel has values in [0-255]
    Each pixel is a 3-d vector (RGB)
    We have n = (num_rows x num_cols) data points that are 3-dimensional
    :return:
    '''''

    # Read in the dataset
    img_file = 'images/mona-lisa'
    ext = '.jpg'
    file_in = img_file + ext

    X = misc.imread(file_in)
    print(X.shape)
    num_rows, num_cols, num_channels = X.shape

    # Rearrange image to n x d
    X = np.vstack(X)
    num_components = 5
    Y = mkmeans(X, K=num_components)

    # Reshape labeling to (num_rows, num_cols) and color with the labeling
    Y = Y.reshape((num_rows, num_cols))
    Y = Y.astype('uint8')

    file_out = img_file + '_K' + str(num_components) + ext
    # plt.imsave(file_out, Y, cmap='gray')
    plt.imshow(Y, cmap='gray')
    plt.show()


if __name__ == '__main__':
    compression_with_kmeans()