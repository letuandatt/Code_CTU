#
#   MLCV Summer 2016
#   Homework Assignment 04 - Gaussian Mixture Models
#
#   Exercise 2) K-Means and EM algorithm
#
###########################################################################

import matplotlib.pyplot as plt
import numpy as np
from time import time
from scipy.spatial.distance import cdist

def compute_assignment(X, means, distance='sqeuclidean'):
    print('Computing distances...')
    n, d = X.shape

    t = time()
    D = cdist(X, means, distance)
    assignment = np.argmin(D, axis=1)
    assignment_cost = np.sum(D[np.arange(n), assignment])

    t = time() - t
    print('Datapoints assigned. Took %fs, cost=%f' % (t, assignment_cost))
    return assignment, assignment_cost


def mkmeans( X, K, plot=False):
    #MKMEANS Summary of this function goes here
    # X - nxdim matrix, the data: n samples with dim properties each
    # K - number of clusters to assign the data to
    n, d = X.shape

    # Initialize cluster means randomly within the data range
    Xmin = np.min(X, axis=0)
    Xmax = np.max(X, axis=0)
    Xrange = Xmax - Xmin
    means = np.array([Xmin + np.random.rand(d)*Xrange for _ in range(K)])

    if plot:
        plt.scatter(X)
        plt.hold(True)
        plt.scatter(means[:, 0], means[:, 1], c=range(K), marker='x')

    # Convergence criteria
    eTol = 1e-2
    converged = False
    maxIter = 100
    it = 0
    while not converged and it < maxIter:

        print('Iteration %d' % it)
        assignment, _ = compute_assignment(X, means)
        # Re-initialize means if a cluster has no samples assigned to it
        while len(set(assignment)) != K:
            print('Some clusters are empty, re-initializing means...')
            means = np.array([Xmin + np.random.rand(d) * Xrange for _ in range(K)])
            assignment, _ = compute_assignment(X, means)

        # Visualize the assignment
        if plot:
            plt.scatter(X[:, 0], X[:, 1], c=assignment)
            plt.scatter(means[:, 0], means[:, 1], c=range(K))
            plt.legend('Iter %d' % it)

        # Compute new means
        old_means = means.copy()
        print('Computing new means...')
        for k in range(K):
            idx = np.array(assignment == k)
            means[k, :] = np.mean(X[idx, :], axis=0)
        print('Done.')

        # Compute the mean shift for each cluster
        print('Computing how much the means shifted...')
        sq_mean_shift = np.zeros(K)
        for k in range(K):
            diff = means[k, :] - old_means[k, :]
            sq_mean_shift[k] = np.dot(diff, diff)
        print('Done.')

        it += 1
        # Evaluate converge criterion
        if all([m < eTol for m in sq_mean_shift]):
            converged = True
            print('Converged after ', it, ' iterations')

    if not converged:
        print('Did not converge after ', it, ' iterations')

    return assignment
