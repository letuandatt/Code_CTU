#
#   MLCV Summer 2016
#   Homework Assignment 04 - Gaussian Mixture Models
#
#   Exercise 2) K-Means and EM algorithm
#
###########################################################################

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from matplotlib import cm
import mkmeans
from scipy import stats


###########################################################################
def compute_random_means(Xmin, Xrange, K):
    print('Computing random means...')
    d = len(Xmin)
    means = np.array([Xmin + np.random.rand(d)*Xrange for _ in range(K)])
    print('Done.')
    return means


###########################################################################
def assign_randomly(X, Xmin, Xrange, K):
    assignment = [0]
    while len(set(assignment)) != K:
        means = compute_random_means(Xmin, Xrange, K)
        assignment, _ = mkmeans.compute_assignment(X, means)
    return assignment


###########################################################################
def init_from_assignment(X, assignment):
    n, d = np.shape(X)
    labels = list(set(assignment))
    K = len(labels)

    means = np.zeros(shape=(K, d))
    covs = np.zeros(shape=(K, d, d))
    # Xcov = np.cov(X)
    for k, label in enumerate(labels):
        idx = np.array([a == label for a in assignment])
        Xc = X[idx, :]
        Xm = np.mean(Xc, axis=0)
        Xc = Xc - Xm[None, :]
        means[k, :] = Xm
        covs[k, :, :] =  np.dot(Xc.T, Xc) / np.sum(idx)

    pie = np.ones(K) / K
    return means, covs, pie


###########################################################################
# Expectation: Compute responsibilities based on current mixture parameters
def compute_responsibilities(X, means, covs, pie, ret='responsibilities'):
    '''
    Expectation step
    γ(z_k) = p(z_k=1|x) = \frac{p(x|z_k=1)(p(z_k=1)}{\sum_j p(z|z_j=1)p(z_j=1)}
        where p(x|z_k=1) = gaussian N(x|μ_k, Σ_k) and p(z_k=1) = π_k
    :param X: data matrix n x d
    :param means: current means of components K x d
    :param covs: current covariances of components K x d x d
    :param pie: current mixture coefficients vector of length K
    :return: responsibilities γ of size n x K
    '''''
    K = len(pie)
    n, d = np.shape(X)
    print('Computing responsibilities...') if ret == 'responsibilities' else print('Computing log-likelihood')

    gamma = np.zeros(shape=(n, K))
    for k in range(K):
        mvn = stats.multivariate_normal.pdf(X, means[k, :], covs[k, :, :], allow_singular=False)
        gamma[:, k] = pie[k] * mvn

    # Normalize responsibilities
    normalizer = np.sum(gamma, axis=1)
    llh = np.sum(np.log(normalizer))

    for k in range(K):
        gamma[:, k] /= normalizer  # n x 1

    print('Done.')
    return gamma, llh


###########################################################################
# Maximization: Update parameters means, covs, pie using current responsibilities
def update_mixture_params(X, gamma):
    '''
    Maximization step
    :param gamma: responsibilities computed in the E-step
    :param X: data matrix d x n
    :return: new means, covariances and mixture coefficients π_k
    '''''
    n, K = np.shape(gamma)
    n, d = np.shape(X)

    print('Updating model parameters...')
    means = np.zeros(shape=(K, d))
    covs = np.zeros(shape=(K, d, d))
    pie = np.zeros(K)
    for k in range(K):
        # Compute normalizer for model k
        Nk = np.sum(gamma[:, k])  # 1 x 1

        # Update mean of model k
        means[k, :] =  np.dot(gamma[:, k].T, X) / Nk # 1 x d

        # Update covariance of model k
        Xk = X - means[None, k, :]  # n x d
        covs[k, :, :] = np.dot(Xk.T, np.dot(np.diag(gamma[:,k]), Xk)) / Nk

        # Update mixing coefficient of model k
        pie[k] = Nk / n

    print('Done.')
    return means, covs, pie


###########################################################################
def cond_plot(it, title=None, data=None, covs=None, colors=None, marker='o', art=None, ax=None):
    if art is not None:
        [a.remove() for a in art]
    artists = []
    plt.sca(ax)
    plt.scatter(data[:, 0], data[:, 1], c=colors, marker=marker, lw=0, s=50)
    if covs is not None:
        K, d = data.shape
        for k in range(K):
            ell = plot_ellipse(plt.gca(), data[k, :], covs[k, :, :], color=colors[k])
            artists.append(ell)
    if title is not None:
        plt.title('%s - %s' % (it, title), fontweight='bold')
    plt.draw()
    plt.pause(0.5)
    return artists

###########################################################################
def plot_ellipse(splot, mean, cov, color):
    v, w = np.linalg.eigh(cov)
    u = w[0] / np.linalg.norm(w[0])
    angle = np.arctan(u[1] / u[0])
    angle = 180 * angle / np.pi  # convert to degrees
    # filled Gaussian at 2 standard deviation
    ell = Ellipse(xy=mean, width=2 * v[0] ** 0.5, height=2 * v[1] ** 0.5, angle=180 + angle,
                    facecolor='lightblue', edgecolor='red', linewidth=2, zorder=2)
    ell.set_clip_box(splot.bbox)
    ell.set_alpha(0.5)
    splot.add_artist(ell)
    return ell


###########################################################################
###########################################################################
def em_gmm( X, K, plot=False):
    # Expectation-Maximization algorithm for Gaussian Mixture Models
    # X - nxd matrix, the data: n samples with d properties each
    # K - number of (gaussian) components to assign the data to
    #
    # gamma - nxk matrix, the responsibilities
    # means - Kxd matrix, the means
    # covs  - Kxdxd array, the covariances
    # pie   - the K mixing coefficients
    # llh   - the final log-likelihood

    n, d = X.shape
    Xmin = np.min(X, axis=0)
    Xmax = np.max(X, axis=0)
    Xrange = Xmax - Xmin

    if plot:
        cmap = cm.get_cmap('jet')
        ccolors = np.array([cmap(float(a + 1) / K) for a in range(K)])
        fig = plt.figure()
        ax1 = fig.add_subplot(1,2,1)
        plt.xlabel('Dim 1')
        plt.ylabel('Dim 2')
        plt.title('Expectation Maximization')
        ax2 = fig.add_subplot(1, 2, 2)
        plt.xlabel('Iteration')
        plt.ylabel('Log-likelihood')
        plt.title('Log-likelihood Maximization', fontweight='bold')
        means_marker = '*'

    np.random.seed(1234)
    restart = True
    while restart:

        # Initialize means randomly within the data range
        means = compute_random_means(Xmin, Xrange, K)
        covs = np.array([np.eye(d) for _ in range(K)])
        pie = np.ones(K) / K
        assignment, _ = mkmeans.compute_assignment(X, means)

        if plot:
            rgba_colors = np.array([cmap(float(a + 1) / K) for a in assignment])
            cond_plot(it='0', data=X, colors=rgba_colors, ax=ax1)
            art = cond_plot(it='0', data=means, covs=covs, colors=ccolors, marker='means_marker', ax=ax1)

        # Convergence criteria
        eTol = 1e-2
        converged = False
        maxIter = 100
        iteration = 0
        # Initialize log-likelihood
        llhs = [-np.inf]
        restart = False
        while not converged and iteration < maxIter:
            # Store log-likelihood
            llh_prev = llhs[-1]
            print('EM iteration %d' % (iteration))
            # E-step: Compute responsibilities based on new means, covs and pie
            try:
                gamma, llh = compute_responsibilities(X, means, covs, pie)
            except np.linalg.LinAlgError:
                print('Singular covariance detected, re-initializing components randomly...')
                restart = True
                break

            # Visualize the new responsibilities
            if plot:
                assignment = np.argmax(gamma, axis=1)
                confidence = gamma[np.arange(n), assignment]
                rgba_colors = np.array([cmap(float(a+1)/K) for a in assignment])
                rgba_colors[:, -1] = confidence
                # print(rgba_colors)
                cond_plot(it=iteration, title='E-step (responsibilities)', data=X, colors=rgba_colors, ax=ax1)

            # Visualize the log-likelihood - skip first iteration plot: llh is arbitrary small
            if iteration > 0:
                llhs.append(llh)
                ax2.plot(llhs, 'b-o') if plot else None
            iteration += 1
            if abs(llh - llh_prev) < eTol:
                converged = True
                print('Converged after %d iterations' % iteration)
                break

            # M-step: Update means, covs and pie based on current responsibilities
            means, covs, pie = update_mixture_params(X, gamma)

            # Visualize the new parameters
            if plot:
                art = cond_plot(it=iteration, title='M-step (new means)', data=means,
                      covs=covs, colors=ccolors, marker='means_marker', art=art, ax=ax1)


        if not restart and not converged:
            print('Did not converge after %d iterations\n' % iteration)
        plt.show() if plot else None

    return gamma, llhs


def expectation_maximization():
    file_in = 'old_faithful.dat'
    X = np.loadtxt(file_in, skiprows=1, usecols=(1,2))
    gamma, llhs = em_gmm(X, K=2, plot=True)


if __name__ == '__main__':
    expectation_maximization()