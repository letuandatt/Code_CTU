void init_graph(Graph *G, int n){
	G->n = n;
	G->m = 0;
}
