#include<stdio.h>

#define MAX_M 500
#define MAX_N 100

typedef struct{
	int n, m;
	int A[MAX_N][MAX_M];
}Graph;

void init_graph(Graph *G, int n, int m){
	int u, e;
	G->n = n;
	G->m = m;
	for(u=1;u<=n;u++)
		for(e=1;e<=n;e++)
			G->A[u][e] = 0;
}

void add_edge(Graph *G, int u, int v, int e){
	G->A[u][e] = 1;
	G->A[v][e] = 1;
}

int adjacent(Graph *G, int u, int v){
	int e;
	for(e=1;e<=G->m;e++)
		if(G->A[u][e] == 1 && G->A[v][e] == 1)
			return 1;
	return 0;
}

int degree(Graph *G, int u){
	int e, deg = 0;
	for(e=1;e<=G->m;e++)
		if(G->A[u][e] == 1)
			deg++;
	return deg;
}

void neighbours(Graph *G, int x){
	int y;
	for(y=1;y<=G->n;y++)
		if(G->A[x][y] != 0)
			printf("%d ", y);
	printf("\n");
}

